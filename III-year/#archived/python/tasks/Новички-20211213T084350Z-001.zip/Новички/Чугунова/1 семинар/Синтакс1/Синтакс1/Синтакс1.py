#Задание 1
clothes = "домашняя одежда";
print('У меня большой гардероб');
print('Утром лучше всего подходит', clothes);

clothes = "удобная одежда";
print('Днем лучше всего подходит', clothes);

clothes = "элегантная одежда";
print('Вечером лучше всего подходит', clothes);

meal = 'завтрак';
print('Мои предпочтения в еде:');
print('Я предпочитаю', meal);

meal = 'обед';
print('Мои предпочтения в еде:');
print('Я предпочитаю', meal);

meal = 'ужин';
print('Мои предпочтения в еде:');
print('Я предпочитаю', meal);


#Задание 2
quilt_width = 8;
quilt_length = 12;
print(quilt_width * quilt_length );

quilt_width = 8;
quilt_length = 8;
print(quilt_width * quilt_length );

a = 13;
b = 23;
print('S =', a*b);