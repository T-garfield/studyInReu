def letter_check(word, letter):
    if letter in word:
        return True
    else:
        return False  

print(letter_check('металлочерепица' , 'е'))