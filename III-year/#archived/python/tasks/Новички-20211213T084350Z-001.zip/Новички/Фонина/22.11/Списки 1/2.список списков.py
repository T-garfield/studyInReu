heights = [['Jenny', 61], ['Alexus', 70], ['Sam', 67], ['Grace', 64], ['Vik', 68]]
age = [['Aaron', 15], ['Dhruti', 16]]