list1 = range (5, 16, 3)
print(list(list1))
list2 = range (0, 41, 5)
print(list(list2))