first_name = "Родриго"
last_name = "Вильянуэва"

account_generator = first_name[:3] + last_name[:3]
#print(account_generator)

new_account = account_generator
print(new_account)