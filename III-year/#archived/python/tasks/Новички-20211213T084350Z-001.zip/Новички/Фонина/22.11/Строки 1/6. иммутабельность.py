first_name = 'Pob'
last_name = 'Daily'
#first_name[0] = "P"
#print(first_name)

fixed_first_name = "R" + first_name[1:]
print(fixed_first_name)