#promise = "I will not chew gum in class"
for promice in range(5):
    print ("I will not chew gum in class") 