def заголовок_функции(num):
    print(num, num*2, num*3)
    return print(num*3)
(заголовок_функции(4))