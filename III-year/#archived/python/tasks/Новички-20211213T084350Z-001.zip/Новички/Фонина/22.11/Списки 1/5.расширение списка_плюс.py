orders = ['маргаритки', 'лютик', 'львиный зев', 'гардения', 'лилия']
new_orders = orders +['сирень', 'ирис']
broken_prices = [5, 3, 4, 5, 4] + [4]
print(new_orders, broken_prices)