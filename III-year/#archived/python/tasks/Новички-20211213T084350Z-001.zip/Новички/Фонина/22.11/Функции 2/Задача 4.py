def z_4 (num):
    if num<8 and num>8:
        return True
    else: 
        return False
print(z_4(8))
