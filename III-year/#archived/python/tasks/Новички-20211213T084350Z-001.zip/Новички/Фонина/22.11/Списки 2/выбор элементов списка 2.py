shopping_list = ['яйца', 'масло', 'молоко', 'огурцы', 'сок', 'хлопья']
last_element = print(shopping_list[-1])
element5 = print(shopping_list[5])