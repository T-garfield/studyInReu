def get_length(str):
 return len(str)
print(get_length('dkjgkdfjgn'))