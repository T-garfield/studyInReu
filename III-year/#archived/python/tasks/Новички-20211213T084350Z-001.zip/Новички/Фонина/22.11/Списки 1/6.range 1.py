list1 = range(1,9)
print(list(list1))
list2 = range(8)
print(list(list2))