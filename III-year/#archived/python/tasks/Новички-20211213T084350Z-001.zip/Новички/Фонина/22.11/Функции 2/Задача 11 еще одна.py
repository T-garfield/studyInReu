def food(total, percent):
    return (total * percent)/100
print(food(1530, 20))