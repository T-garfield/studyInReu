first_name = "Родриго"
last_name = "Вильянуэва"

new_account = last_name[:5]
print(new_account)

temp_password = last_name[2:6]
print(temp_password)