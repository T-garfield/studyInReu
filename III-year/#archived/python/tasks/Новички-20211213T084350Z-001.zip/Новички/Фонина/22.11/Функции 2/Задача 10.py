def намберс (num1, num2):
    t = (num1 * 2)%(num2/2)
    return t
print(намберс(4.6,8))