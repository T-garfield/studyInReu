variable_password = "theycallme\"crazy\"91"
print(variable_password)