def tenth_power(num):
    return num ** 10
import math
def square_root(num):
    return int(math.sqrt(num)) #*sqrt - тока квадратный корень, в остальных случаях -> "... ** 1/степень"*
print(tenth_power(2), square_root(1024))
