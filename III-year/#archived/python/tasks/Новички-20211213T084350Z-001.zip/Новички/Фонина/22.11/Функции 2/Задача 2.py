def range (num, low_limit, high_limit):
    if num >= low_limit and num <= high_limit:
        return True
    else:
        return False
print(range(2675672,2672342,26734272))
