games = ['Portal', 'Minecraft', 'Pacman', 'Tetris', 'The Sims', 'Pokemon']
sorted_games = sorted(games)
print(sorted_games)