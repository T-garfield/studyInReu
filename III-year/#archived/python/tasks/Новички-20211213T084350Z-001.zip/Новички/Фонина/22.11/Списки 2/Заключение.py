inventory = ['twin bed', 'twin bed', 'headboard', 'queen bed', 'king bed',
'dresser', 'dresser', 'table', 'table', 'nightstand', 'nightstand', 'kingbed', 
'king bed', 'twin bed', 'twin bed', 'sheets', 'sheets', 'pillow', 'pillow']
inventory_len = print(len(inventory))
first = print(inventory[:1])
last = print(inventory[-1:])
inventory_2_6 = print(inventory[2:6])
first3 = print(inventory[:3])
twin_beds = print(inventory.count("twin bed"))
sorted_inventory = (inventory.sort())