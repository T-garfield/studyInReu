favour_word = "бетон"
print("Мое любимое слово -", favour_word)