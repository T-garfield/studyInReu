def create_spreadsheet(title = "Загрузки ", row_count = 1000):
    print("Создание электронной таблицы с именем "+ title + 'c ' + str(row_count) + " строк" )
create_spreadsheet(title = "Приложения ", row_count = 10)
