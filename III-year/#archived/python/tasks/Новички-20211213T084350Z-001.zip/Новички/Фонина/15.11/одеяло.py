quilt_width = 8
quilt_lenght = 12
quilt_size = quilt_width * quilt_lenght
print("количество лоскутов равно" , quilt_size)

