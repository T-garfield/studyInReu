#1
clothes = "домашняя одежда"
print ("У меня большой гардероб")
print ("Утром лучше всего подходит " + clothes)
clothes = "уличная одежда"
print ("У меня большой гардероб")
print ("Днем лучше всего подходит " + clothes)
clothes = "вечерний наряд"
print ("У меня большой гардероб")
print ("Ночью лучше всего подходит " + clothes)
meal = "салат цезарь"
print ("мои предпочтения в еде")
print ("на обед люблю " + meal)
meal = "яичницу"
print ("на завтрак люблю " + meal)
meal = "фуагра"
print ("на ужин люблю " + meal)
#второе задание
quilt_width = 8
quilt_length = 12
print(quilt_width*quilt_length)
#3
length = 23
width = 13
print(width*length)