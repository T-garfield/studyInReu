#Матвеев
a = 2
b = 3
a,b = b,a 
print(a,b)
