#Матвеев Александр
print('Одежда и еда')
clothes = "домашняя одежда"
print('У меня большой гардероб')
print('Утром лучше всего подходит', clothes)
clothes = "кэжуал одежда"
print('Днем лучше всего подходит', clothes)
clothes = "свободная одежда"
print('Вечером лучше всего подходит', clothes)
clothes = "пижама"
print('Ночью лучше всего подходит', clothes)
print('Мои предпочтения в еде')
meal = "яичницу"
print('На завтрак я предпочитаю', meal)
meal = "котлетки"
print('На обед я предпочитаю', meal)
meal = "много котлеток"
print('На ужин я предпочитаю', meal)
print('')
print('Одеяло')
quilt_width = 8
quilt_length = 8
print('Для одеяла потребуется', quilt_width*quilt_length, 'лоскутов')
print('')
print('Прямоугольник')
a = 23
b = 13
print('Площадь прямоугольника =', a*b)





