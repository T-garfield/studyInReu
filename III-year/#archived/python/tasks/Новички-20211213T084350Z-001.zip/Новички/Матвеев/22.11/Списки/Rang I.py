#Matveev
list1 = range(10)
list2 = range(8)
print(list(list1))
print(list(list2))
