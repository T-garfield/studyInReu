#Matveev
suitcase = ['рубашка', 'рубашка', 'брюки', 'брюки', 'пижамы', 'книги']
beginning = suitcase [0: 4]
print(beginning)
middle = suitcase[2 : 4]
print(middle)