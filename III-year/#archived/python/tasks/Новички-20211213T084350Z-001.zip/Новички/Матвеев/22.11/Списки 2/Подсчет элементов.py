#Matveev
votes = ['Jake', 'Jake', 'Laurie', 'Laurie', 'Laurie', 'Jake', 'Jake', 
         'Jake', 'Laurie', 'Cassie', 'Cassie', 'Jake', 'Jake', 'Cassie', 
         'Laurie', 'Cassie', 'Jake','Jake', 'Cassie', 'Laurie']
jake_votes = votes.count('Jake')
print(jake_votes)
