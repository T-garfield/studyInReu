#Matveev
list1 = range(2, 20, 3)
print(len(list1))
