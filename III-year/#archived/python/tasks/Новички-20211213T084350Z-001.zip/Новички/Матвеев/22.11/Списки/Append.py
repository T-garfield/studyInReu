#Матвеев
orders = ['маргаритки', 'барвинок']
print(orders)
orders.append('Тюльпаны')
orders.append('Розы')
print(orders)
