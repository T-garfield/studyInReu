quilt_width = 8
quilt_length = 12

print (quilt_width * quilt_length)


quilt_length = 8

print (quilt_width * quilt_length)

print("рассчитать площадь прямоугольника")

length = 23
hight = 13

print ("площадь прямоугольника равна", length * hight)