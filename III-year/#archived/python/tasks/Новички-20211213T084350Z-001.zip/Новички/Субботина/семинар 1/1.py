#1 задание (одежда и еда)
clothes = "домашняя одежда"
print ("У меня большой гардероб")
print ("Утром лучше всего подходит " + clothes)
clothes = "повседневная одежда"
print ("У меня большой гардероб")
print ("Днем лучше всего подходит " + clothes)
clothes = "нарядная одежда"
print ("У меня большой гардероб")
print ("Ночью лучше всего подходит " + clothes)
meal = "сырники"
print ("Мои предпочтения в еде на завтрак")
print ("Люблю кушать " + meal)
meal = "суп"
print ("Мои предпочтение в еде на обед")
print ("Люблю кушать " + meal)
meal = "пасту"
print ("Мои предпочтение в еде на ужин")
print ("Люблю кушать " + meal)

#2 задание (одеяло)
quilt_width = 8
quilt_length = 12
print(quilt_width*quilt_length)

#3 задание (площадь прямоугольника)
length = 23
width = 13
print(width*length)