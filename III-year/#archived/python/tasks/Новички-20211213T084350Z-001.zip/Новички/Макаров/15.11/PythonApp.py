clothes = "домашнняя одежда" 
#2
print("у меня большой гардероб") 
morning = "утром лучше всего подходит"
print(morning,clothes)
day = "днем лучше всего подходит"
print(day,clothes)
evening = "вечером лучше всего подходит"
print (evening,clothes)
night = "ночью лучше всего подходит"
print (night,clothes)
#3
meal = "быстро растворимая лапша"
print("мои предпочтения в еде")
breakfast = "На завтрак лучше всего подходит"
print (breakfast,meal)
lunch = "На обед лучше всего подходит"
print (lunch,meal)
dinner = "На ужин лучше всего подходит"
print (dinner,meal)
#4
print ("Задание№2")
quilt_width = 8
quilt_length = 12
#количество квадратов
print(quilt_width * quilt_length)
print(quilt_width * 8)



