clothes = "домашняя одежда"
print(clothes)
clothes1 = "У меня большой гардероб"
print(clothes1)
clothes3 = "Утром"
clothes4 = "Днем"
clothes5 = "Вечером"
clothes6 = "Ночью"
clothes2 = " лучше всего подходит домашняя одежда"
print(clothes3+clothes2)
print(clothes4+clothes2)
print(clothes5+clothes2)
breakfast="на завтрак:яичница"
lunch="на обед: борщ"
dinner="на обед: что попадется"
meal = "Мои предпочтения в еде "
print(meal+breakfast)
print(meal+lunch)
print(meal+dinner)


quilt_width=8
quilt_length=12
print(quilt_width*quilt_length)

quilt_length=8
print(quilt_width*quilt_length)

width=13
length=23
print(width*length)
