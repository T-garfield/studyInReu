#1 

clothes = "домашняя одежда"
print("У меня большой гардероб")
print("Утром лучше всего подходит " + clothes)
clothes = "не домашняя одежда"
print("Днем лучше всего подходит " + clothes)
clothes = "опять домашняя одежда"
print("Вечером лучше всего подходит " + clothes)
clothes = "пижама"
print("Ночью лучше всего подходит " + clothes)

#2

print()
meal = "хлопья с молоком"
print("Мои предпочтения в еде на завтрак " + meal)
meal = "куриный суп"
print("Мои предпочтения в еде на обед " + meal)
meal = "стейк с рисом"
print("Мои предпочтения в еде на ужин " + meal)

#3

print()
quilt_width = 8
quilt_length = 12
print("Необходимое количество квадратов: "+ str(quilt_width * quilt_length))
print()
quilt_width = 8
quilt_length = 8
print("Новое количество квадратов: "+ str(quilt_width * quilt_length))
print()
side_a = 23
side_b = 13
print("Площадь прямоугольника равна: " + str(side_a * side_b))