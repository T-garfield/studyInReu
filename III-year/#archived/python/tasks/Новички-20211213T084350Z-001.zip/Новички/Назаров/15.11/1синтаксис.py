#1
clothes='домашняя одежда'
meal='мясо'
print('У меня большой гардероб.' '\n'
'Утром лучше всего подходит',clothes, '\n'
'Днем лучше всего подходит',clothes, '\n'
'Вечером лучше всего подходит',clothes, '\n'
'Ночью лучше всего подходит',clothes) 
print('Мои предпочтения в еде.' , '\n'
'Для завтрака лучше всего подходит',meal, '\n'
'Для обеда всего подходит',meal, '\n'
'Для ужина лучше всего подходит',meal)
#2
quilt_width=8
quilt_length=12
print(quilt_width*quilt_length)

quilt_width=8
quilt_length=8
print(quilt_width*quilt_length)

rectangle_w=23
rectangle_l=13
print(rectangle_w*rectangle_l)