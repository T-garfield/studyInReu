quilt_width = 8
quilt_length = 8
#Вычислить количество лоскутов (8 на 8) и вывести
print((quilt_length*quilt_width))

