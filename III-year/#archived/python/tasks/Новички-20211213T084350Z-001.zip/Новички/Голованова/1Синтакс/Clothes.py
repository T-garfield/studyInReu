'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

clothes = "домашняя оджда"
print (clothes)
clothes = "У меня большой гардероб"
print (clothes)
#Утром
clothes = "Утром лучше всего подходит домашняя одежда"
print (clothes)
#Днем
clothes = "Днем лучше всего подходит домашняя одежда"
print (clothes)
#Вечером
clothes = "Вечером лучше всего подходит домашняя одежда"
print (clothes)
#Ночью
clothes = "Ночью лучше всего подходит домашняя одежда"
print (clothes)
