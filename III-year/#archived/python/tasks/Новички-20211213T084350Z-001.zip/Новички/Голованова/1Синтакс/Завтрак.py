breakfast="Утром лучше всего есть яичницу"
lunch="Днем лучше всего есть суп"
dinner="Вечером лучше всего есть макароны"
meal = "Мои предпочтения в еде"
print(meal+breakfast)
print(meal+lunch)
print(meal+dinner)
