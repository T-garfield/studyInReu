# 1
clothes = "домашняя одежда"
print('У меня большой гардероб')
print('Утром лучше всего подходит ' + clothes)
print('Днем лучше всего подходит ' + clothes)
print('Вечером лучше всего подходит ' + clothes)
print('Ночью лучше всего подходит ' + clothes)
meal = "хлеб"
print('мои предпочтения в еде')
print('На завтрак я ем ' + meal)
print('На обед я ем ' + meal)
print('На ужин я ем ' + meal)
# 2
quilt_width = 8
quilt_length = 12
print(quilt_length * quilt_width)
quilt_length = 8
print(quilt_length * quilt_width)
square_width = 13
square_length = 23
print(square_length*square_width)
