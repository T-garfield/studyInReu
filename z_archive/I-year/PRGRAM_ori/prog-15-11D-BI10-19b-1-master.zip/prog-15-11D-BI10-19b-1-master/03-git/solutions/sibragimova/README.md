# Программирование
# sibragimova
* Заголовки
 * "#" This is an <h1> tag
 * "##" This is an <h2> tag
 * "######" This is an <h6> tag
 * Выделение, подчеркивание
  * "*This text will be italic*"
  * "*_This will also be italic_*"
  * "**This text will be bold**"
  * "__This will also be bold__"
  * "_You **can** combine them_"
* Списки
   * подпункт
     * подпункт подпункта
  * подпункт
* Картинки
* "Format: ![Alt Text](url)"
* Ссылки
* "[GitHub](http://github.com)"
* Цитаты
  * As Kanye West said:

> We're living the future so
> the present is our past.
> 
* Код
I think you should use an
`<addr>` element here instead.
