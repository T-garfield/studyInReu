# Программирование

## nguyenducthien

### Syntax guide

#### Headers
`
 # This is an <h1> tag
 ## This is an <h2> tag
 ###### This is an <h6> tag
#### Emphasis
 *This text will be italic*
 _This will also be italic_

 **This text will be bold**
 __This will also be bold__

#### List

##### Unodered

 * Item 1
 * Item 2
   * Item 2a
   * Item 2b

##### Odered

 1. Item 1
 1. Item 2
 1. Item 3
    1. Item 3a
    1. Item 3b

#### Images

 ![github logo](https://cdn.worldvectorlogo.com/logos/github-octocat.svg)

#### Links

[This is a link](https://www.google.ru/)

#### Blockquotes

 As Kayne West said:

 > We're living in the future so 
 > the present is out past.

#### Inline code

I think you should use an 
`<addr>` element here instead

    or this






