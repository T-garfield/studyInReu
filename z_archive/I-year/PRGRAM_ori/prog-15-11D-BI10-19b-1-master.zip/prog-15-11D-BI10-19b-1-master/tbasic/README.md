# Basic

TINY BASIC User Manual - грамматика
http://users.telenet.be/kim1-6502/tinybasic/tbum.html
(дополнение)
http://users.telenet.be/kim1-6502/tinybasic/tbek.html

The Return of Tiny Basic - грамматика и алгоритм 
http://www.drdobbs.com/web-development/the-return-of-tiny-basic/184406381
Исходный код:
http://www.drdobbs.com/web-development/the-return-of-tiny-basic/web-development/sourcecode/the-return-of-tiny-basic/30000164

http://www.ittybittycomputers.com/IttyBitty/TinyBasic/
Design Notes for Tiny Basic - грамматика и алгоритм 
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/DDJ1/Design.html
Tiny Basic letters
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/DDJ1/Letters.html
Build Your Own Basic
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/DDJ1/BYOB.html
Running Light Without Overbyte
http://www.ittybittycomputers.com/IttyBitty/TinyBasic/DDJ1/


tinybc - Tiny BASIC for Curses - более сложный; исходный код и много примеров
http://tinybc.sourceforge.net/
Tiny BASIC manual for beginners
http://tinybc.sourceforge.net/tinybctut.txt

TBasic - A simple BASIC interpreter written in C++ - исходники на C++
https://sourceforge.net/p/tbasic/code/ci/master/tree/Basic.h

blassic - есть программы
http://blassic.net/download.html

4th - есть программы
https://sourceforge.net/projects/forth-4th/?source=typ_redirect


# Forth
a tiny self-hosted Forth implementation
https://github.com/kragen/stoneknifeforth
Tiny C compiler written in Forth
https://groups.google.com/forum/#!msg/comp.lang.forth/lBYFfVJ1qhc/BxvaTHCX_JgJ
IVM (IV Machine or Forth Machine)
http://zserge.bitbucket.org/j1vm.html
Itsy-Forth: the Outer Interpreter of a 1K Tiny Compiler
http://www.retroprogramming.com/2012/03/itsy-forth-1k-tiny-compiler.html

================================================================================

1. clone Git repository
2. установка Node
3. установка npm, установка пакетов
4. unit tests

1. lineParser
- source




