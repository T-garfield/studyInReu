/**
 * Created by alykoshin on 20.09.16.
 */

'use strict';

const readlineSync = require('readline-sync');

const debug  = require('./lib/debug.js');
const ERRORS = require('./lib/errors.json');
const Tbasic = require('./lib/tbasic.js');

// for future use
//var ErrorHandler = require('./lib/errorHandler.js');


(function() {

  const tbasic = new Tbasic();

  // print names of available operators
  //let opNames = [];
  //for (let name in tbasic.operators) {
  //  debug('name: '+ name);
  //  if (typeof tbasic.operators[ name ] === 'function') opNames.push(name);
  //}
  //const opNames = Object.getOwnPropertyNames(tbasic.operators);
  //const opNames = Object.(Object.getPrototypeOf(tbasic.operators));
  const opNames = Object.keys(tbasic.operators.handlers);
  debug('Available operators: '+ opNames.join(', '));

  // load file if provided in command line
  if (process.argv[2]) {
    tbasic.source.load(process.argv[2]);
  }


  var rl = readlineSync;
  var cont = true;
  do {
    var line = rl.question(':');

    try {
      cont = !line || tbasic.do_line_interactive(line);
    } catch(e) {
      console.log(`ERROR AT LINE ${tbasic.source.lineNo} POS ${tbasic.parser.pos}`);
      console.log(`${tbasic.parser.line}`);
      let s = '';
      for (let i=0; i<tbasic.parser.pos; i++) s += ' ';
      s += '^';
      console.log(s);
      debug(`line: "${tbasic.parser.line}", pos: ${tbasic.parser.pos}`);
      console.log(e.message, e.stack);
    }

  } while (cont);


})();
