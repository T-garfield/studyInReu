# Программирование

Ссылки:
[Расписание](https://docs.google.com/spreadsheets/d/1wRlgpfDTH0lP_lhDzsxmYIwnLgcYc2F_dnLEMFspya0/htmlview?pru=AAABchJUsxg*v3O_v5ptbYieMQQz2K0zkQ#gid=0) 
[Moodle](https://study.rea.ru/course/view.php?id=15565)
[Github](https://github.com/cathedra/prog-15-11D-BI10-19b-1)
[Trello](https://trello.com/b/jY18Zxod/%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-1511%D0%B4-%D0%B1%D0%B810-19%D0%B1-%D0%BF%D0%BE%D0%B4%D0%B3%D1%80%D1%83%D0%BF%D0%BF%D0%B0-1)

## Группа 15.11Д-БИ10-19б (подгруппа 1)

Все задания сгруппированы по каталогам. 
В каждом каталоге задания есть два подкаталога: `assignments`  и `solutions`

В подкаталоге `assignments` размещаются файлы самого задания; задание описано в файле `README.md`.
`solution` предназначен для вашей работы.

Если в каком-то задании порядок работы отличается, это будет отмечено дополнительно в его README.

