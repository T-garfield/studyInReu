describe('return', function() {

it('is a function', function() {
expect(tbasic.operators.handlers.return).to.be.a('function');
})
it('test for normal work ', function() {
tbasic.operators.stack = [{ 'lineIdx': 2, 'pos': 4 }]
tbasic.operators.handlers.return()
expect(tbasic.source.lineIdx).to.equal(2)
expect(tbasic.parser.pos).to.equal(4)
})
})