Задание
=======
- получить API key, задать его в файле `credentials.json` по аналогии с файлом `credentials.example.json`
- добавить вызов функции собственно перевода фиксированного текста
- Добавить перевод собственного произвольного текста 

Документация
============
- API introduction (Russian): https://tech.yandex.ru/translate/
- Get API key: https://tech.yandex.ru/keys/get/?service=trnsl
- My keys: https://tech.yandex.ru/keys/
- API docs: https://tech.yandex.ru/translate/doc/dg/concepts/About-docpage/
